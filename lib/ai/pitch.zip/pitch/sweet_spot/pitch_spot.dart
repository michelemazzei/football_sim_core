import 'package:flame/components.dart';

class PitchSpot {
  final Vector2 pos;
  double score;

  PitchSpot(this.pos, [this.score = 0.0]);
}
