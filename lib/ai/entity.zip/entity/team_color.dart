enum TeamColor { home, away }
