enum TeamDirection { fromLeftToRight, fromRightToLeft }
