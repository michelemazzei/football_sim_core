class PlayerRegion {
  int home;
  int homeWhenAttacking;
  int homeWhenDefending;
  PlayerRegion({
    required this.home,
    required this.homeWhenAttacking,
    required this.homeWhenDefending,
  });
}
